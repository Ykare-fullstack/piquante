module.exports = {
    //...
    devServer: {
      historyApiFallback: true,
    },
  };